create function st_asjpeg(rast raster, nband integer, quality integer)
  returns bytea
immutable
strict
language sql
as $$
SELECT st_asjpeg($1, ARRAY[$2], $3)
$$;

