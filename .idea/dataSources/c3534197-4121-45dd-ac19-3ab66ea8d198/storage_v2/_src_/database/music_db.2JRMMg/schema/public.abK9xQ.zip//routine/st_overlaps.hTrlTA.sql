create function st_overlaps(rast1 raster, rast2 raster)
  returns boolean
immutable
cost 1000
language sql
as $$
SELECT st_overlaps($1, NULL::integer, $2, NULL::integer)
$$;

