create function st_aslatlontext(geometry)
  returns text
immutable
strict
language sql
as $$
SELECT ST_AsLatLonText($1, '')
$$;

