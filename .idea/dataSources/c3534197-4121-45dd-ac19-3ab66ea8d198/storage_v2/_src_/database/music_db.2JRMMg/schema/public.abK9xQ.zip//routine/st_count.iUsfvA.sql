create function st_count(rast raster, exclude_nodata_value boolean)
  returns bigint
immutable
strict
language sql
as $$
SELECT _st_count($1, 1, $2, 1)
$$;

