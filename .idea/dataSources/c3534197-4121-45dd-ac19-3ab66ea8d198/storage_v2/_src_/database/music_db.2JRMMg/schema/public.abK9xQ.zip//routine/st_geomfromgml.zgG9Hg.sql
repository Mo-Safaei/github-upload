create function st_geomfromgml(text)
  returns geometry
immutable
strict
language sql
as $$
SELECT _ST_GeomFromGML($1, 0)
$$;

