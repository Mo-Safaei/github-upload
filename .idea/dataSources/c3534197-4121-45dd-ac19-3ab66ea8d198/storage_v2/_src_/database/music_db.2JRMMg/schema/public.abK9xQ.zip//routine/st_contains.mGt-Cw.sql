create function st_contains(rast1 raster, rast2 raster)
  returns boolean
immutable
cost 1000
language sql
as $$
SELECT st_contains($1, NULL::integer, $2, NULL::integer)
$$;

