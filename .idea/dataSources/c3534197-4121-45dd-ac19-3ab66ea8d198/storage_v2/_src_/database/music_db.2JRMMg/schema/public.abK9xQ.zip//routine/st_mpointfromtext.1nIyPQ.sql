create function st_mpointfromtext(text, integer)
  returns geometry
immutable
strict
language sql
as $$
SELECT CASE WHEN geometrytype(ST_GeomFromText($1, $2)) = 'MULTIPOINT'
	THEN ST_GeomFromText($1, $2)
	ELSE NULL END

$$;

