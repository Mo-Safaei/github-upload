create function st_approxsummarystats(rast raster, exclude_nodata_value boolean, sample_percent double precision DEFAULT 0.1, OUT count bigint, OUT sum double precision, OUT mean double precision, OUT stddev double precision, OUT min double precision, OUT max double precision)
  returns record
immutable
strict
language sql
as $$
SELECT _st_summarystats($1, 1, $2, $3)
$$;

