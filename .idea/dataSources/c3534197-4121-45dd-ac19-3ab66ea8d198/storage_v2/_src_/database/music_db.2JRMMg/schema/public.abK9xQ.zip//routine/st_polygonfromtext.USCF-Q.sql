create function st_polygonfromtext(text, integer)
  returns geometry
immutable
strict
language sql
as $$
SELECT ST_PolyFromText($1, $2)
$$;

