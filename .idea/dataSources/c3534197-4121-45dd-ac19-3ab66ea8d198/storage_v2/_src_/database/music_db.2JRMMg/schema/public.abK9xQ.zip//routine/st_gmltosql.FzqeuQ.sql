create function st_gmltosql(text)
  returns geometry
immutable
strict
language sql
as $$
SELECT _ST_GeomFromGML($1, 0)
$$;

