create function st_rastertoworldcoordx(rast raster, xr integer, yr integer)
  returns double precision
immutable
strict
language sql
as $$
SELECT longitude FROM _st_rastertoworldcoord($1, $2, $3)
$$;

