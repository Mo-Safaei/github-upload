create function st_worldtorastercoordx(rast raster, xw double precision)
  returns integer
immutable
strict
language sql
as $$
SELECT columnx FROM _st_worldtorastercoord($1, $2, NULL)
$$;

