create function st_multilinestringfromtext(text)
  returns geometry
immutable
strict
language sql
as $$
SELECT ST_MLineFromText($1)
$$;

