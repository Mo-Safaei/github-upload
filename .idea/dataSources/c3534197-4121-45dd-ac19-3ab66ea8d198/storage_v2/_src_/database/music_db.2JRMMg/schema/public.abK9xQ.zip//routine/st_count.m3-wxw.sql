create function st_count(rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true)
  returns bigint
immutable
strict
language sql
as $$
SELECT _st_count($1, $2, $3, 1)
$$;

