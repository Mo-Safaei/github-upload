create function st_setvalue(rast raster, x integer, y integer, newvalue double precision)
  returns raster
language sql
as $$
SELECT st_setvalue($1, 1, $2, $3, $4)
$$;

