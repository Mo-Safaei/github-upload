create function st_area(text)
  returns double precision
immutable
strict
language sql
as $$
SELECT ST_Area($1::geometry);
$$;

