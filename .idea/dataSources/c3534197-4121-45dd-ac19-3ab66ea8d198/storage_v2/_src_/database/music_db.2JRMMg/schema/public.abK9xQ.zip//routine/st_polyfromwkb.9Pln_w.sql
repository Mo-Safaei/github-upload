create function st_polyfromwkb(bytea, integer)
  returns geometry
immutable
strict
language sql
as $$
SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1, $2)) = 'POLYGON'
	THEN ST_GeomFromWKB($1, $2)
	ELSE NULL END

$$;

