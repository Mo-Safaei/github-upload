create function st_orderingequals(geometrya geometry, geometryb geometry)
  returns boolean
immutable
strict
language sql
as $$
SELECT $1 ~= $2 AND _ST_OrderingEquals($1, $2)

$$;

