create function st_valuecount(rastertable text, rastercolumn text, nband integer, exclude_nodata_value boolean, searchvalue double precision, roundto double precision DEFAULT 0)
  returns integer
stable
strict
language sql
as $$
SELECT (_st_valuecount($1, $2, $3, $4, ARRAY[$5]::double precision[], $6)).count
$$;

