create function st_rastertoworldcoordy(rast raster, yr integer)
  returns double precision
immutable
strict
language sql
as $$
SELECT latitude FROM _st_rastertoworldcoord($1, NULL, $2)
$$;

