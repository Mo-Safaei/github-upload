create function raster_contained_by_geometry(raster, geometry)
  returns boolean
immutable
strict
language sql
as $$
select $1::geometry @ $2
$$;

