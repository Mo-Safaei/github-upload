create function st_rotation(raster)
  returns double precision
language sql
as $$
SELECT (ST_Geotransform($1)).theta_i
$$;

