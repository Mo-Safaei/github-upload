create function st_containsproperly(rast1 raster, rast2 raster)
  returns boolean
immutable
cost 1000
language sql
as $$
SELECT st_containsproperly($1, NULL::integer, $2, NULL::integer)
$$;

