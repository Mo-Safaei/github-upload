create function st_mpolyfromwkb(bytea, integer)
  returns geometry
immutable
strict
language sql
as $$
SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1, $2)) = 'MULTIPOLYGON'
	THEN ST_GeomFromWKB($1, $2)
	ELSE NULL END

$$;

