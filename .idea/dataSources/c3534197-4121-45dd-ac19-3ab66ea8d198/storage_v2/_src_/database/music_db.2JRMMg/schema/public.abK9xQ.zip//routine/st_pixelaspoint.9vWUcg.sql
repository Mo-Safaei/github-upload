create function st_pixelaspoint(rast raster, x integer, y integer)
  returns geometry
immutable
strict
language sql
as $$
SELECT ST_PointN(ST_ExteriorRing(geom), 1) FROM _st_pixelaspolygons($1, NULL, $2, $3)
$$;

