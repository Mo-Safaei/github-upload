create function postgis_scripts_installed()
  returns text
immutable
language sql
as $$
SELECT '2.1.7'::text || ' r' || 13414::text AS version
$$;

