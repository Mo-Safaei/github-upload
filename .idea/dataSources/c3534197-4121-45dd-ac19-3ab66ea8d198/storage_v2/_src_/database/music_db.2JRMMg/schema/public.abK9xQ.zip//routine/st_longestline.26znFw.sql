create function st_longestline(geom1 geometry, geom2 geometry)
  returns geometry
immutable
strict
language sql
as $$
SELECT _ST_LongestLine(ST_ConvexHull($1), ST_ConvexHull($2))
$$;

