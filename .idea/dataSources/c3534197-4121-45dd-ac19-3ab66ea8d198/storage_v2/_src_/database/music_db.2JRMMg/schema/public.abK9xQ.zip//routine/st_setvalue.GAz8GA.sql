create function st_setvalue(rast raster, nband integer, geom geometry, newvalue double precision)
  returns raster
immutable
language sql
as $$
SELECT st_setvalues($1, $2, ARRAY[ROW($3, $4)]::geomval[], FALSE)
$$;

