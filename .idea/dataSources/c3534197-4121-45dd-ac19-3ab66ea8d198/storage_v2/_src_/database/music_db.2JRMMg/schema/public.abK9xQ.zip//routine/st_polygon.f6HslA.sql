create function st_polygon(geometry, integer)
  returns geometry
immutable
strict
language sql
as $$
SELECT ST_SetSRID(ST_MakePolygon($1), $2)

$$;

