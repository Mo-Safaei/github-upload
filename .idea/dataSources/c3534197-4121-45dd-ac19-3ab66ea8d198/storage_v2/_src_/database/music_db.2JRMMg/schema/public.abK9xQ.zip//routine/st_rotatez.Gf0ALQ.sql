create function st_rotatez(geometry, double precision)
  returns geometry
immutable
strict
language sql
as $$
SELECT ST_Rotate($1, $2)
$$;

