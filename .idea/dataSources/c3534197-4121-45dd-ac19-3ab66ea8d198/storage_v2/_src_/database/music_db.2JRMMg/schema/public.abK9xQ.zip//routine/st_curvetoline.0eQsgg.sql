create function st_curvetoline(geometry)
  returns geometry
immutable
strict
language sql
as $$
SELECT ST_CurveToLine($1, 32)
$$;

