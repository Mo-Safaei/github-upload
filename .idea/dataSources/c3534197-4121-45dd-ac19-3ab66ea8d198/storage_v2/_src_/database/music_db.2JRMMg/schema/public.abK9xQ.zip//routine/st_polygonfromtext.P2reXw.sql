create function st_polygonfromtext(text)
  returns geometry
immutable
strict
language sql
as $$
SELECT ST_PolyFromText($1)
$$;

