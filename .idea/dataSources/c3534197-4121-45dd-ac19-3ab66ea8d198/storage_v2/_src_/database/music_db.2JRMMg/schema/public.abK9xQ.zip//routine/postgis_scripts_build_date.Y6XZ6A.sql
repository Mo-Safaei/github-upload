create function postgis_scripts_build_date()
  returns text
immutable
language sql
as $$
SELECT '2015-03-31 03:41:27'::text AS version
$$;

