create function st_distance(geography, geography, boolean)
  returns double precision
immutable
strict
language sql
as $$
SELECT _ST_Distance($1, $2, 0.0, $3)
$$;

