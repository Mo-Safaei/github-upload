create function st_pixelaspoints(rast raster, band integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, OUT geom geometry, OUT val double precision, OUT x integer, OUT y integer)
  returns SETOF record
immutable
strict
language sql
as $$
SELECT ST_PointN(ST_ExteriorRing(geom), 1), val, x, y FROM _st_pixelaspolygons($1, $2, NULL, NULL, $3)
$$;

