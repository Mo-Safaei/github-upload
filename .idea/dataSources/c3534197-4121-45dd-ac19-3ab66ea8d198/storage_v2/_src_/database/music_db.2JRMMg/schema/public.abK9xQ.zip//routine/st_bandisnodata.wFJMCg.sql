create function st_bandisnodata(rast raster, forcechecking boolean)
  returns boolean
immutable
strict
language sql
as $$
SELECT st_bandisnodata($1, 1, $2)
$$;

