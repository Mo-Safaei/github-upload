create function st_askml(geog geography, maxdecimaldigits integer DEFAULT 15)
  returns text
immutable
strict
language sql
as $$
SELECT _ST_AsKML(2, $1, $2, null)
$$;

