create function st_distinct4ma(value double precision[], pos integer[], VARIADIC userargs text[] DEFAULT NULL::text[])
  returns double precision
immutable
language sql
as $$
SELECT COUNT(DISTINCT unnest)::double precision FROM unnest($1)
$$;

