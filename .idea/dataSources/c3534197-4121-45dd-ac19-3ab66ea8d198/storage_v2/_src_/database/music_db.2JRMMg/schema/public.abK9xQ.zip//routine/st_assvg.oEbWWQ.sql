create function st_assvg(text)
  returns text
immutable
strict
language sql
as $$
SELECT ST_AsSVG($1::geometry,0,15);
$$;

