create function st_covers(rast1 raster, rast2 raster)
  returns boolean
immutable
cost 1000
language sql
as $$
SELECT st_covers($1, NULL::integer, $2, NULL::integer)
$$;

