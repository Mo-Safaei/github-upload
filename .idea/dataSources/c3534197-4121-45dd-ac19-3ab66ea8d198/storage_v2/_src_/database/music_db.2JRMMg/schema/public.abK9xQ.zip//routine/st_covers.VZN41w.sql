create function st_covers(geography, geography)
  returns boolean
immutable
language sql
as $$
SELECT $1 && $2 AND _ST_Covers($1, $2)
$$;

