create function st_pixelaspolygon(rast raster, x integer, y integer)
  returns geometry
immutable
strict
language sql
as $$
SELECT geom FROM _st_pixelaspolygons($1, NULL, $2, $3)
$$;

