create function st_pointfromtext(text)
  returns geometry
immutable
strict
language sql
as $$
SELECT CASE WHEN geometrytype(ST_GeomFromText($1)) = 'POINT'
	THEN ST_GeomFromText($1)
	ELSE NULL END

$$;

