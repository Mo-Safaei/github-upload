create function st_asbinary(geography, text)
  returns bytea
immutable
strict
language sql
as $$
SELECT ST_AsBinary($1::geometry, $2);
$$;

