create function st_geomfromwkb(bytea, integer)
  returns geometry
immutable
strict
language sql
as $$
SELECT ST_SetSRID(ST_GeomFromWKB($1), $2)
$$;

