create function box3dtobox(box3d)
  returns box
immutable
strict
language sql
as $$
SELECT box($1)
$$;

