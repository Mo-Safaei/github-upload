create function st_patchn(geometry, integer)
  returns geometry
immutable
strict
language sql
as $$
SELECT CASE WHEN ST_GeometryType($1) = 'ST_PolyhedralSurface'
	THEN ST_GeometryN($1, $2)
	ELSE NULL END

$$;

