create function st_approxhistogram(rastertable text, rastercolumn text, nband integer, exclude_nodata_value boolean, sample_percent double precision, bins integer, "right" boolean, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision)
  returns SETOF record
stable
strict
language sql
as $$
SELECT _st_histogram($1, $2, $3, $4, $5, $6, NULL, $7)
$$;

