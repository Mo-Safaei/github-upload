create function st_tile(rast raster, width integer, height integer, padwithnodata boolean DEFAULT false, nodataval double precision DEFAULT NULL::double precision)
  returns SETOF raster
immutable
language sql
as $$
SELECT _st_tile($1, $2, $3, NULL::integer[], $4, $5)
$$;

