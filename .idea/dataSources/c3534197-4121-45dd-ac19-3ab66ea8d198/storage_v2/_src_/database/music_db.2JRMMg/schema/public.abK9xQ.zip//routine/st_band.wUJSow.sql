create function st_band(rast raster, nband integer)
  returns raster
immutable
strict
language sql
as $$
SELECT st_band($1, ARRAY[$2])
$$;

